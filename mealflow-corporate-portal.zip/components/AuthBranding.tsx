
// This component is no longer used in the simplified version.
export default () => null;
