
import React, { useState, useMemo } from 'react';
import { FoodListing, FoodRequest, ImpactStats, DashboardView } from '../types';
import Input from './Input';

const DEFAULT_STATS: ImpactStats = {
  mealsRedistributed: 1240,
  wasteReducedKg: 850,
  orgsHelped: 14
};

const ZERO_STATS: ImpactStats = {
  mealsRedistributed: 0,
  wasteReducedKg: 0,
  orgsHelped: 0
};

const INITIAL_LISTINGS: FoodListing[] = [
  { 
    id: '1', 
    title: 'Assorted Pastries', 
    quantity: '15 units', 
    expiry: 'Today, 10:00 PM', 
    location: 'Downtown Cafe', 
    status: 'active',
    storageInstructions: 'Keep in dry, cool area.',
    allergens: ['gluten', 'dairy'],
    preparedAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString()
  },
  { 
    id: '2', 
    title: 'Steamed Rice & Veg', 
    quantity: '20kg', 
    expiry: 'Today, 8:00 PM', 
    location: 'Grand Hotel', 
    status: 'active',
    storageInstructions: 'Keep refrigerated at all times.',
    allergens: [],
    preparedAt: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString()
  },
];

const INITIAL_REQUESTS: FoodRequest[] = [
  { id: '1', organization: 'City Shelter', neededItems: 'Ready meals', urgency: 'high', distance: '1.2 km' },
  { id: '2', organization: 'Greenway NGO', neededItems: 'Fresh produce', urgency: 'medium', distance: '3.5 km' },
  { id: '3', organization: 'Hope Harbor', neededItems: 'Baked goods', urgency: 'low', distance: '0.8 km' },
  { id: '4', organization: 'Community Kitchen', neededItems: 'Protein sources', urgency: 'high', distance: '2.4 km' },
];

const INITIAL_PICKUPS = [
  { id: 'p1', org: 'City Shelter', item: 'Assorted Breads', quantity: '10 Trays', time: '6:00 PM', date: 'Today', location: 'North Side Bakery', status: 'Scheduled' },
  { id: 'p2', org: 'Greenway NGO', item: 'Fruit Basket', quantity: '5kg Mixed', time: '7:30 PM', date: 'Today', location: 'Central Market', status: 'In Progress' },
  { id: 'p3', org: 'Hope Harbor', item: 'Soup Bases', quantity: '12 Liters', time: '4:00 PM', date: 'Yesterday', location: 'Grand Hotel', status: 'Completed' },
];

const ALLERGEN_OPTIONS = [
  { id: 'dairy', label: 'Dairy' },
  { id: 'nuts', label: 'Nuts' },
  { id: 'gluten', label: 'Gluten' },
  { id: 'eggs', label: 'Eggs' },
];

const SidebarItem: React.FC<{ icon: string; label: string; active?: boolean; onClick: () => void }> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all text-sm font-medium cursor-pointer ${active ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20' : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 dark:text-slate-400'}`}
  >
    <i className={`fa-solid ${icon} w-5 text-center`}></i>
    <span>{label}</span>
  </button>
);

interface DashboardProps {
  onLogout: () => void;
  isNewUser: boolean;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onLogout, isNewUser, darkMode, onToggleDarkMode }) => {
  const [activeView, setActiveView] = useState<DashboardView>('dashboard');
  const [stats, setStats] = useState<ImpactStats>(isNewUser ? ZERO_STATS : DEFAULT_STATS);
  const [listings, setListings] = useState<FoodListing[]>(isNewUser ? [] : INITIAL_LISTINGS);
  const [requests, setRequests] = useState<FoodRequest[]>(isNewUser ? [] : INITIAL_REQUESTS);
  const [pickups, setPickups] = useState(isNewUser ? [] : INITIAL_PICKUPS);
  const [scheduleFilter, setScheduleFilter] = useState('All');
  
  // Post Form State
  const [postForm, setPostForm] = useState({
    title: '',
    quantity: '',
    expiry: '',
    location: '',
    storageInstructions: '',
    preparedAt: '',
    allergens: [] as string[],
    otherAllergen: ''
  });
  const [isPosting, setIsPosting] = useState(false);
  const [selectedListing, setSelectedListing] = useState<FoodListing | null>(null);
  const [selectedPickup, setSelectedPickup] = useState<any>(null);
  const [viewingRequestId, setViewingRequestId] = useState<string | null>(null);

  // Settings state
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const handleAllergenToggle = (id: string) => {
    setPostForm(prev => ({
      ...prev,
      allergens: prev.allergens.includes(id) 
        ? prev.allergens.filter(a => a !== id) 
        : [...prev.allergens, id]
    }));
  };

  const handleAddPost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!postForm.preparedAt) {
      alert("Please specify when the food was prepared for safety compliance.");
      return;
    }
    
    setIsPosting(true);
    setTimeout(() => {
      const finalAllergens = [...postForm.allergens];
      if (postForm.otherAllergen.trim()) {
        finalAllergens.push(postForm.otherAllergen.trim());
      }

      const listing: FoodListing = {
        id: Math.random().toString(36).substr(2, 9),
        title: postForm.title,
        quantity: postForm.quantity,
        expiry: postForm.expiry,
        location: postForm.location,
        storageInstructions: postForm.storageInstructions,
        preparedAt: new Date(postForm.preparedAt).toISOString(),
        allergens: finalAllergens,
        status: 'active'
      };

      setListings([listing, ...listings]);
      setPostForm({ title: '', quantity: '', expiry: '', location: '', storageInstructions: '', preparedAt: '', allergens: [], otherAllergen: '' });
      setIsPosting(false);
      setActiveView('dashboard');
    }, 800);
  };

  const handleAcceptPickup = (id: string) => {
    const req = requests.find(r => r.id === id);
    if (req) {
      setRequests(requests.filter(r => r.id !== id));
      setStats(prev => ({
        ...prev,
        mealsRedistributed: prev.mealsRedistributed + 1,
        orgsHelped: prev.orgsHelped + 1
      }));
      setPickups([{
        id: `p-${Date.now()}`,
        org: req.organization,
        item: req.neededItems,
        quantity: 'Unspecified Batch',
        time: 'TBD',
        date: 'Today',
        location: 'Pending Address',
        status: 'Scheduled'
      }, ...pickups]);
      setViewingRequestId(null);
    }
  };

  const markPickupCompleted = (id: string) => {
    setPickups(pickups.map(p => p.id === id ? { ...p, status: 'Completed' } : p));
  };

  const filteredPickups = useMemo(() => {
    if (scheduleFilter === 'All') return pickups;
    return pickups.filter(p => p.status === scheduleFilter);
  }, [pickups, scheduleFilter]);

  const renderContent = () => {
    switch(activeView) {
      case 'dashboard':
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-500">
            {/* Quick Actions */}
            <div className="flex flex-wrap gap-4">
              <button onClick={() => setActiveView('post')} className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2.5 rounded-lg font-medium transition-all shadow-lg shadow-emerald-500/20 cursor-pointer">
                <i className="fa-solid fa-plus"></i> Post Surplus Food
              </button>
              <button onClick={() => setActiveView('requests')} className="flex items-center gap-2 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-900 px-5 py-2.5 rounded-lg font-medium transition-all cursor-pointer">
                <i className="fa-solid fa-hand-holding-dollar"></i> Browse Requests
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm">
                <p className="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Meals Shared</p>
                <div className="flex items-end gap-3">
                  <span className="text-3xl font-bold dark:text-white">{stats.mealsRedistributed.toLocaleString()}</span>
                </div>
              </div>
              <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm">
                <p className="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Waste Reduced (kg)</p>
                <div className="flex items-end gap-3">
                  <span className="text-3xl font-bold dark:text-white">{stats.wasteReducedKg} kg</span>
                </div>
              </div>
              <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm">
                <p className="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Orgs Empowered</p>
                <div className="flex items-end gap-3">
                  <span className="text-3xl font-bold dark:text-white">{stats.orgsHelped}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Active Pickups Operational Overview */}
              <section>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold dark:text-white">Active Pickups</h3>
                  <button onClick={() => setActiveView('schedule')} className="text-xs text-emerald-500 font-bold uppercase tracking-widest hover:underline cursor-pointer">View Schedule</button>
                </div>
                <div className="space-y-4">
                  {pickups.filter(p => p.status !== 'Completed').length === 0 ? (
                    <div className="py-12 text-center bg-slate-50 dark:bg-slate-900/20 rounded-xl border border-dashed border-slate-200 dark:border-slate-800">
                      <i className="fa-solid fa-truck-fast text-slate-300 dark:text-slate-700 text-3xl mb-3"></i>
                      <p className="text-slate-500 dark:text-slate-400 text-sm">No active pickups scheduled.</p>
                    </div>
                  ) : (
                    pickups.filter(p => p.status !== 'Completed').map(p => (
                      <div 
                        key={p.id} 
                        className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-100 dark:border-slate-800 hover:border-emerald-500/30 transition-all group shadow-sm"
                      >
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <h4 className="font-bold text-emerald-600 dark:text-emerald-400 text-xs uppercase tracking-wider mb-1">{p.org}</h4>
                            <h5 className="font-bold text-slate-900 dark:text-white group-hover:text-emerald-500 transition-colors">{p.item}</h5>
                            <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">{p.location}</p>
                          </div>
                          <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${p.status === 'In Progress' ? 'bg-blue-100 text-blue-600' : 'bg-amber-100 text-amber-600'}`}>
                            {p.status}
                          </span>
                        </div>
                        <div className="flex items-center justify-between mt-4">
                           <div className="flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
                            <div className="flex items-center gap-1.5">
                              <i className="fa-solid fa-box-open opacity-60"></i>
                              <span>{p.quantity}</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <i className="fa-solid fa-calendar opacity-60"></i>
                              <span>{p.date}, {p.time}</span>
                            </div>
                          </div>
                          <button 
                            onClick={() => setSelectedPickup(p)}
                            className="text-[10px] text-slate-400 hover:text-slate-900 dark:hover:text-white font-bold uppercase tracking-widest transition-colors cursor-pointer"
                          >
                            View Details
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </section>

              <section>
                <h3 className="text-lg font-bold dark:text-white mb-4">Nearby Requests</h3>
                <div className="space-y-4">
                  {requests.slice(0, 3).map(req => (
                    <div key={req.id} className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-100 dark:border-slate-800 flex items-center gap-4">
                      <div className="flex-1">
                        <h4 className="font-bold text-slate-900 dark:text-white text-sm">{req.organization}</h4>
                        <p className="text-slate-500 dark:text-slate-400 text-xs">Needs: {req.neededItems}</p>
                      </div>
                      <button onClick={() => setViewingRequestId(req.id)} className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold uppercase tracking-tight hover:underline cursor-pointer">View Details</button>
                    </div>
                  ))}
                  <button onClick={() => setActiveView('requests')} className="w-full py-2 text-xs font-bold text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors uppercase tracking-widest">See all requests</button>
                </div>
              </section>
            </div>
          </div>
        );

      case 'post':
        return (
          <div className="max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom-2 duration-500 pb-12">
            <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl">
              <div className="flex items-center gap-3 mb-8 border-b border-slate-100 dark:border-slate-800 pb-6">
                <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-xl flex items-center justify-center">
                  <i className="fa-solid fa-plus-circle text-2xl"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold dark:text-white">Post Surplus Food</h3>
                  <p className="text-slate-500 text-sm">Ensure all details are accurate for compliance and safety.</p>
                </div>
              </div>

              <form onSubmit={handleAddPost} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input label="Item Title" placeholder="e.g. Mixed Deli Sandwiches" value={postForm.title} onChange={e => setPostForm({...postForm, title: e.target.value})} required />
                  <Input label="Quantity" placeholder="e.g. 20 units" value={postForm.quantity} onChange={e => setPostForm({...postForm, quantity: e.target.value})} required />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input label="Expiry Info" placeholder="e.g. Today by 8PM" value={postForm.expiry} onChange={e => setPostForm({...postForm, expiry: e.target.value})} required />
                  <Input label="Pickup Location" placeholder="e.g. Main Kitchen, 2nd Floor" value={postForm.location} onChange={e => setPostForm({...postForm, location: e.target.value})} required />
                </div>

                <div className="pt-6 border-t border-slate-100 dark:border-slate-800 space-y-6">
                  <div className="flex items-center gap-2 mb-4">
                    <i className="fa-solid fa-shield-halved text-emerald-500"></i>
                    <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-xs">Food Safety Notes</h4>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Prepared At</label>
                      <input 
                        type="datetime-local" 
                        value={postForm.preparedAt}
                        onChange={e => setPostForm({...postForm, preparedAt: e.target.value})}
                        className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-slate-900 dark:text-slate-100 text-sm"
                        required
                      />
                    </div>
                    <Input label="Storage Instructions" placeholder="e.g. Keep refrigerated below 5°C" value={postForm.storageInstructions} onChange={e => setPostForm({...postForm, storageInstructions: e.target.value})} required />
                  </div>

                  <div className="space-y-3">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Allergen Information</label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {ALLERGEN_OPTIONS.map(opt => (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => handleAllergenToggle(opt.id)}
                          className={`flex items-center justify-center gap-2 px-4 py-2 rounded-lg border text-xs font-semibold transition-all ${postForm.allergens.includes(opt.id) ? 'bg-emerald-50 border-emerald-500 text-emerald-600 dark:bg-emerald-900/20 dark:border-emerald-500' : 'bg-slate-50 border-slate-200 text-slate-500 dark:bg-slate-800/50 dark:border-slate-700'}`}
                        >
                          <i className={`fa-solid ${postForm.allergens.includes(opt.id) ? 'fa-check-circle' : 'fa-circle-plus opacity-40'}`}></i>
                          {opt.label}
                        </button>
                      ))}
                    </div>
                    <Input label="Other Allergens" placeholder="Separate by commas" value={postForm.otherAllergen} onChange={e => setPostForm({...postForm, otherAllergen: e.target.value})} />
                  </div>
                </div>

                <div className="pt-6 flex gap-4">
                  <button type="button" onClick={() => setActiveView('dashboard')} className="flex-1 py-3 text-slate-500 dark:text-slate-400 font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all cursor-pointer">
                    Back to Overview
                  </button>
                  <button type="submit" disabled={isPosting} className="flex-[2] bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-lg transition-all shadow-lg shadow-emerald-500/20 cursor-pointer flex items-center justify-center gap-2">
                    {isPosting ? <i className="fa-solid fa-circle-notch animate-spin"></i> : <><i className="fa-solid fa-check-shield"></i> Submit Secure Listing</>}
                  </button>
                </div>
              </form>
            </div>
          </div>
        );

      case 'requests':
        if (viewingRequestId) {
          const r = requests.find(item => item.id === viewingRequestId);
          if (!r) return null;
          return (
            <div className="max-w-2xl mx-auto animate-in fade-in slide-in-from-bottom-2 duration-500">
              <button onClick={() => setViewingRequestId(null)} className="mb-6 flex items-center gap-2 text-sm text-slate-500 hover:text-emerald-500 font-medium transition-colors">
                <i className="fa-solid fa-arrow-left"></i> Back to Requests
              </button>
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden">
                <div className="p-8 border-b border-slate-100 dark:border-slate-800">
                  <div className={`inline-block px-3 py-1 rounded-full text-[10px] font-bold uppercase mb-4 ${r.urgency === 'high' ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-600'}`}>
                    {r.urgency} Priority Request
                  </div>
                  <h3 className="text-2xl font-bold dark:text-white mb-2">{r.organization}</h3>
                  <p className="text-slate-500 text-lg">Needs: <span className="text-slate-900 dark:text-slate-200 font-semibold">{r.neededItems}</span></p>
                </div>
                <div className="p-8 space-y-6">
                  <div className="grid grid-cols-2 gap-8">
                    <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Contact Person</p>
                      <p className="text-sm font-semibold dark:text-slate-200">Maria Rodriguez</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Distance</p>
                      <p className="text-sm font-semibold dark:text-slate-200">{r.distance} away</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Pickup Window</p>
                      <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-500">Anytime before 9:00 PM</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Requirements</p>
                      <p className="text-sm font-semibold dark:text-slate-200">Clean containers only</p>
                    </div>
                  </div>
                  <div className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-xl border border-slate-200 dark:border-slate-700">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-widest mb-2">Special Notes</h4>
                    <p className="text-sm text-slate-600 dark:text-slate-400 italic">"Our shelter currently has 40 residents. Any warm meals would be greatly appreciated tonight."</p>
                  </div>
                  <button 
                    onClick={() => handleAcceptPickup(r.id)}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-emerald-500/20 cursor-pointer text-lg"
                  >
                    Accept & Schedule Pickup
                  </button>
                </div>
              </div>
            </div>
          );
        }
        return (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-bold dark:text-white">Active NGO Demands</h3>
              <div className="flex gap-2">
                <button className="px-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-bold text-slate-500 hover:text-emerald-500 transition-all">
                  Filter by Priority
                </button>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {requests.map(req => (
                <div key={req.id} className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-md transition-all">
                  <div className="flex justify-between mb-4">
                    <div className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${req.urgency === 'high' ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-600'}`}>
                      {req.urgency} Priority
                    </div>
                    <span className="text-slate-400 text-xs font-medium">{req.distance} away</span>
                  </div>
                  <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-1">{req.organization}</h4>
                  <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">Needs: <span className="text-slate-700 dark:text-slate-300 font-medium">{req.neededItems}</span></p>
                  <button 
                    onClick={() => setViewingRequestId(req.id)}
                    className="w-full bg-slate-100 dark:bg-slate-800 hover:bg-emerald-600 hover:text-white dark:text-slate-300 py-2.5 rounded-lg font-bold transition-all text-sm cursor-pointer"
                  >
                    View Details
                  </button>
                </div>
              ))}
            </div>
          </div>
        );

      case 'schedule':
        return (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xl font-bold dark:text-white">Logistics Overview</h3>
              <div className="flex gap-2">
                {['All', 'Scheduled', 'In Progress', 'Completed'].map(f => (
                  <button 
                    key={f}
                    onClick={() => setScheduleFilter(f)}
                    className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${scheduleFilter === f ? 'bg-emerald-600 text-white' : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-emerald-500'}`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-slate-50/50 dark:bg-slate-800/20 border-b border-slate-100 dark:border-slate-800">
                    <tr>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Date & Time</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Organization</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Item / Quantity</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredPickups.map(p => (
                      <tr key={p.id} className="hover:bg-slate-50/30 dark:hover:bg-slate-800/30 transition-colors">
                        <td className="px-6 py-4">
                          <p className="text-sm font-bold dark:text-white">{p.date}</p>
                          <p className="text-xs text-slate-400">{p.time}</p>
                        </td>
                        <td className="px-6 py-4">
                          <p className="text-sm font-semibold dark:text-slate-200">{p.org}</p>
                          <p className="text-xs text-slate-400">{p.location}</p>
                        </td>
                        <td className="px-6 py-4 text-sm dark:text-slate-300">
                          {p.item} <span className="text-xs opacity-50">({p.quantity})</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${p.status === 'Completed' ? 'bg-emerald-100 text-emerald-600' : p.status === 'In Progress' ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-600'}`}>
                            {p.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          {p.status !== 'Completed' && (
                            <button 
                              onClick={() => markPickupCompleted(p.id)}
                              className="text-xs font-bold text-emerald-600 hover:text-emerald-500 hover:underline transition-colors"
                            >
                              Mark Completed
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                    {filteredPickups.length === 0 && (
                      <tr>
                        <td colSpan={5} className="px-6 py-12 text-center text-slate-400 italic">No pickups found for this filter.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      case 'reports':
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-500">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold dark:text-white">Impact Analytics</h3>
              <button className="flex items-center gap-2 px-4 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-lg text-xs font-bold hover:opacity-90 transition-all">
                <i className="fa-solid fa-download"></i> Export Data
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm text-center">
                <i className="fa-solid fa-heart text-red-500 text-2xl mb-4"></i>
                <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mb-1">Total Meals Shared</p>
                <p className="text-4xl font-black dark:text-white">{stats.mealsRedistributed.toLocaleString()}</p>
              </div>
              <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm text-center">
                <i className="fa-solid fa-leaf text-emerald-500 text-2xl mb-4"></i>
                <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mb-1">Waste Reduced</p>
                <p className="text-4xl font-black dark:text-white">{stats.wasteReducedKg} kg</p>
              </div>
              <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm text-center">
                <i className="fa-solid fa-handshake text-blue-500 text-2xl mb-4"></i>
                <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mb-1">Organizations Supported</p>
                <p className="text-4xl font-black dark:text-white">{stats.orgsHelped}</p>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <h4 className="font-bold text-slate-900 dark:text-white mb-8">Weekly Impact Trend</h4>
              <div className="h-64 flex items-end justify-between gap-4">
                {[45, 60, 85, 40, 95, 110, 80].map((val, idx) => (
                  <div key={idx} className="flex-1 flex flex-col items-center group">
                    <div 
                      style={{ height: `${val}%` }} 
                      className="w-full bg-emerald-600/20 group-hover:bg-emerald-600 rounded-t-lg transition-all relative"
                    >
                      <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] font-bold py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                        {val}kg
                      </div>
                    </div>
                    <p className="text-[10px] font-bold text-slate-400 uppercase mt-4">Day {idx + 1}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'settings':
        return (
          <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-2 duration-500 space-y-8 pb-12">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Profile Card */}
              <div className="lg:col-span-2 space-y-8">
                <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                  <h4 className="font-bold text-slate-900 dark:text-white mb-6">Organization Profile</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Input label="Admin Name" defaultValue={isNewUser ? 'John Doe' : 'Marcus Aurelius'} />
                    <Input label="Email" defaultValue="admin@mealflow.org" />
                    <Input label="Organization" defaultValue={isNewUser ? 'Fresh Start' : 'Grand Bistro Group'} />
                    <Input label="Phone" defaultValue="+1 (555) 123-4567" />
                  </div>
                  <div className="mt-8 flex justify-end">
                    <button className="bg-slate-900 dark:bg-white text-white dark:text-slate-950 px-6 py-2.5 rounded-lg font-bold text-sm hover:opacity-90 transition-all">
                      Save Profile Changes
                    </button>
                  </div>
                </div>

                <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                  <h4 className="font-bold text-slate-900 dark:text-white mb-6">Security & Password</h4>
                  <div className="space-y-4">
                    <Input label="Current Password" type="password" placeholder="••••••••" />
                    <Input label="New Password" type="password" placeholder="••••••••" />
                  </div>
                  <div className="mt-8 flex justify-end">
                    <button className="border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 px-6 py-2.5 rounded-lg font-bold text-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition-all">
                      Update Security
                    </button>
                  </div>
                </div>
              </div>

              {/* Sidebar Settings */}
              <div className="space-y-8">
                <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                  <h4 className="font-bold text-slate-900 dark:text-white mb-6">Preferences</h4>
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-bold dark:text-white">Push Notifications</p>
                        <p className="text-xs text-slate-500">New urgent requests</p>
                      </div>
                      <button 
                        onClick={() => setNotificationsEnabled(!notificationsEnabled)}
                        className={`w-10 h-6 rounded-full transition-colors relative ${notificationsEnabled ? 'bg-emerald-600' : 'bg-slate-200 dark:bg-slate-700'}`}
                      >
                        <div className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${notificationsEnabled ? 'translate-x-4' : ''}`}></div>
                      </button>
                    </div>
                  </div>
                </div>

                <div className="bg-red-50 dark:bg-red-900/10 p-8 rounded-2xl border border-red-100 dark:border-red-900/30 shadow-sm">
                  <h4 className="font-bold text-red-600 mb-2">Account Action</h4>
                  <p className="text-xs text-red-500/80 mb-6">Sign out of all sessions and clear temporary cache.</p>
                  <button onClick={onLogout} className="w-full bg-red-600 text-white py-3 rounded-lg font-bold text-sm hover:bg-red-700 transition-all cursor-pointer">
                    Sign Out Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  }

  return (
    <div className="flex h-screen bg-white dark:bg-slate-950 transition-colors overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 border-r border-slate-200 dark:border-slate-800 p-6 flex flex-col hidden lg:flex bg-white dark:bg-slate-950 z-40">
        <div className="flex items-center gap-2 mb-10 px-2">
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
            <i className="fa-solid fa-leaf text-white text-sm"></i>
          </div>
          <span className="font-bold text-xl dark:text-white tracking-tight">MealFlow</span>
        </div>

        <nav className="flex-1 space-y-1">
          <SidebarItem icon="fa-chart-pie" label="Dashboard" active={activeView === 'dashboard'} onClick={() => { setActiveView('dashboard'); setViewingRequestId(null); }} />
          <SidebarItem icon="fa-plus-circle" label="Post Food" active={activeView === 'post'} onClick={() => { setActiveView('post'); setViewingRequestId(null); }} />
          <SidebarItem icon="fa-hand-holding-heart" label="Requests" active={activeView === 'requests'} onClick={() => { setActiveView('requests'); setViewingRequestId(null); }} />
          <SidebarItem icon="fa-calendar-check" label="Pickup Schedule" active={activeView === 'schedule'} onClick={() => { setActiveView('schedule'); setViewingRequestId(null); }} />
          <SidebarItem icon="fa-file-lines" label="Impact Reports" active={activeView === 'reports'} onClick={() => { setActiveView('reports'); setViewingRequestId(null); }} />
          <SidebarItem icon="fa-gear" label="Settings" active={activeView === 'settings'} onClick={() => { setActiveView('settings'); setViewingRequestId(null); }} />
        </nav>

        <button onClick={onLogout} className="mt-auto flex items-center gap-3 px-4 py-3 text-slate-400 hover:text-red-500 transition-colors text-sm font-medium cursor-pointer">
          <i className="fa-solid fa-arrow-right-from-bracket"></i>
          <span>Log out</span>
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden bg-slate-50/30 dark:bg-slate-950/30">
        <header className="h-16 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-8 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md z-30">
          <h2 className="text-slate-900 dark:text-white font-bold tracking-tight">
            {activeView.charAt(0).toUpperCase() + activeView.slice(1)}
          </h2>
          <div className="flex items-center gap-4">
            <button 
              onClick={onToggleDarkMode}
              className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors cursor-pointer"
              title="Toggle dark mode"
            >
              <i className={`fa-solid ${darkMode ? 'fa-sun text-amber-400' : 'fa-moon text-slate-400'}`}></i>
            </button>
            <button className="relative p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer">
              <i className="fa-solid fa-bell"></i>
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white dark:border-slate-950"></span>
            </button>
            <div onClick={() => setActiveView('settings')} className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 overflow-hidden cursor-pointer hover:ring-2 ring-emerald-500/50 transition-all">
              <img src={`https://api.dicebear.com/7.x/initials/svg?seed=${isNewUser ? 'NP' : 'MA'}`} alt="Profile" />
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8">
          {renderContent()}
        </div>
      </main>

      {/* Pickup Details Modal */}
      {selectedPickup && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden scale-in">
            <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/20">
              <h3 className="font-bold text-slate-900 dark:text-white">Active Pickup Details</h3>
              <button onClick={() => setSelectedPickup(null)} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors text-slate-400">
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="p-8 space-y-6">
              <div>
                <p className="text-emerald-600 font-bold text-xs uppercase tracking-widest mb-1">{selectedPickup.org}</p>
                <h4 className="text-2xl font-bold dark:text-white mb-1">{selectedPickup.item}</h4>
                <p className="text-slate-500 text-sm">{selectedPickup.location} • {selectedPickup.quantity}</p>
              </div>

              <div className="grid grid-cols-2 gap-6 pt-4 border-t border-slate-100 dark:border-slate-800">
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Scheduled Time</p>
                  <p className="text-sm font-semibold dark:text-slate-200">{selectedPickup.date}, {selectedPickup.time}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Operational Status</p>
                  <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-500">{selectedPickup.status}</p>
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl flex items-center gap-3">
                <i className="fa-solid fa-truck-ramp-box text-emerald-500"></i>
                <div>
                  <p className="text-xs font-bold dark:text-white uppercase tracking-tighter">Logistics Note</p>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Driver dispatched. ETA 15 mins.</p>
                </div>
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => { markPickupCompleted(selectedPickup.id); setSelectedPickup(null); }}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-emerald-500/20"
                >
                  Confirm Completion
                </button>
                <button 
                  onClick={() => setSelectedPickup(null)}
                  className="px-6 py-3 border border-slate-200 dark:border-slate-800 text-slate-500 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Listing Details Modal */}
      {selectedListing && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden scale-in">
            <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/20">
              <h3 className="font-bold text-slate-900 dark:text-white">Listing Specifications</h3>
              <button onClick={() => setSelectedListing(null)} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors text-slate-400">
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="p-8 space-y-6">
              <div>
                <h4 className="text-2xl font-bold dark:text-white mb-1">{selectedListing.title}</h4>
                <p className="text-slate-500 text-sm">{selectedListing.location} • {selectedListing.quantity}</p>
              </div>

              <div className="grid grid-cols-2 gap-6 pt-4 border-t border-slate-100 dark:border-slate-800">
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Prepared Time</p>
                  <p className="text-sm font-semibold dark:text-slate-200">{new Date(selectedListing.preparedAt).toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Expiry Objective</p>
                  <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-500">{selectedListing.expiry}</p>
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl space-y-4">
                <div className="flex gap-3">
                  <i className="fa-solid fa-temperature-low text-blue-500 mt-1"></i>
                  <div>
                    <p className="text-xs font-bold dark:text-white uppercase tracking-tighter">Storage Guidelines</p>
                    <p className="text-sm text-slate-600 dark:text-slate-400">{selectedListing.storageInstructions}</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <i className="fa-solid fa-circle-exclamation text-amber-500 mt-1"></i>
                  <div>
                    <p className="text-xs font-bold dark:text-white uppercase tracking-tighter">Verified Allergens</p>
                    {selectedListing.allergens.length > 0 ? (
                      <div className="flex flex-wrap gap-2 mt-2">
                        {selectedListing.allergens.map(a => (
                          <span key={a} className="px-2 py-0.5 bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 text-[10px] font-bold rounded">
                            {a.toUpperCase()}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-slate-500 dark:text-slate-400">No allergens flagged by producer.</p>
                    )}
                  </div>
                </div>
              </div>

              <button 
                onClick={() => setSelectedListing(null)}
                className="w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold py-3 rounded-xl hover:opacity-90 transition-all"
              >
                Close Specification
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
