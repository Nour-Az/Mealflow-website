
import React, { useState, useEffect } from 'react';
import { AuthMode } from '../types';
import Input from './Input';
import Dashboard from './Dashboard';

const App: React.FC = () => {
  const [mode, setMode] = useState<AuthMode>('signin');
  const [loading, setLoading] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isNewUser, setIsNewUser] = useState(false);
  
  // Initialize dark mode from localStorage or system preference
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('theme');
      if (savedTheme) return savedTheme === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  // Update document class whenever darkMode state changes
  useEffect(() => {
    const root = window.document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  const toggleDarkMode = () => setDarkMode(prev => !prev);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      setIsNewUser(mode === 'signup');
      setIsAuthenticated(true);
    }, 1200);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setMode('signin');
    setIsNewUser(false);
  };

  if (isAuthenticated) {
    return (
      <Dashboard 
        onLogout={handleLogout} 
        isNewUser={isNewUser} 
        darkMode={darkMode} 
        onToggleDarkMode={toggleDarkMode} 
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-slate-50 dark:bg-slate-950 transition-colors duration-300">
      {/* Theme Toggle Button */}
      <button 
        type="button"
        onClick={toggleDarkMode}
        className="fixed top-6 right-6 w-10 h-10 flex items-center justify-center rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all shadow-sm z-50 cursor-pointer"
        aria-label="Toggle dark mode"
      >
        <i className={`fa-solid ${darkMode ? 'fa-sun text-amber-400' : 'fa-moon text-slate-600'}`}></i>
      </button>

      <div className="w-full max-w-[400px]">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-emerald-600 rounded-xl mb-4 shadow-sm shadow-emerald-500/20">
            <i className="fa-solid fa-leaf text-white text-xl"></i>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white transition-colors tracking-tight">MealFlow</h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-3 transition-colors leading-relaxed px-4 max-w-[320px] mx-auto">
            {mode === 'signin' 
              ? "Food is wasted daily while charities face shortages — the real issue is poor coordination and timing." 
              : "Create an account to start streamlining food distribution."}
          </p>
        </div>

        {/* Auth Card */}
        <div className="bg-white dark:bg-slate-900/50 p-8 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 transition-all duration-300">
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <Input label="Organization Name" placeholder="e.g. Grand Bistro" required />
            )}
            
            <Input 
              label="Work Email" 
              type="email" 
              placeholder="name@organization.com" 
              required 
            />

            <Input 
              label="Password" 
              type="password" 
              placeholder="••••••••" 
              required 
            />

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-slate-900 dark:bg-white hover:bg-slate-800 dark:hover:bg-slate-100 text-white dark:text-slate-950 font-semibold py-3 rounded-lg transition-all flex items-center justify-center gap-2 disabled:opacity-70 mt-2 shadow-sm"
            >
              {loading ? (
                <i className="fa-solid fa-circle-notch animate-spin"></i>
              ) : (
                <>{mode === 'signin' ? 'Sign In' : 'Create Portal'}</>
              )}
            </button>
          </form>

          {/* Minimal Navigation */}
          <div className="mt-6 text-center text-sm">
            {mode === 'signin' ? (
              <p className="text-slate-500 dark:text-slate-400 transition-colors font-medium">
                New to MealFlow? <button onClick={() => setMode('signup')} className="text-emerald-600 dark:text-emerald-500 font-bold hover:underline transition-colors cursor-pointer">Join now</button>
              </p>
            ) : (
              <button onClick={() => setMode('signin')} className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 transition-colors cursor-pointer font-medium">Already have an account? Log in</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;