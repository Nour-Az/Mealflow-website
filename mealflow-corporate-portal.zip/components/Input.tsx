
import React, { useState } from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
}

const Input: React.FC<InputProps> = ({ label, type, ...props }) => {
  const [isVisible, setIsVisible] = useState(false);
  const isPassword = type === 'password';
  const inputType = isPassword ? (isVisible ? 'text' : 'password') : type;

  return (
    <div className="space-y-1">
      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">
        {label}
      </label>
      <div className="relative group">
        <input
          {...props}
          type={inputType}
          className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/5 dark:focus:ring-white/5 focus:border-slate-400 dark:focus:border-slate-500 transition-all text-slate-900 dark:text-slate-100 placeholder-slate-400 text-sm"
        />
        {isPassword && (
          <button
            type="button"
            onClick={() => setIsVisible(!isVisible)}
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
            tabIndex={-1}
          >
            <i className={`fa-solid ${isVisible ? 'fa-eye-slash' : 'fa-eye'} text-sm`}></i>
          </button>
        )}
      </div>
    </div>
  );
};

export default Input;
