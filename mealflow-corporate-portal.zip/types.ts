
export type AuthMode = 'signin' | 'signup';

export interface ApiResponse<T> {
  data?: T;
  error?: string;
}

export interface ImpactStats {
  mealsRedistributed: number;
  wasteReducedKg: number;
  orgsHelped: number;
}

export interface FoodListing {
  id: string;
  title: string;
  quantity: string;
  expiry: string;
  location: string;
  status: 'active' | 'pending' | 'completed' | 'expiring';
  storageInstructions: string;
  allergens: string[];
  preparedAt: string;
}

export interface FoodRequest {
  id: string;
  organization: string;
  neededItems: string;
  urgency: 'high' | 'medium' | 'low';
  distance: string;
}

export type DashboardView = 'dashboard' | 'post' | 'requests' | 'schedule' | 'reports' | 'settings';
